from django.urls import path
from . import views

# urlpatterns = [
#     path('', views.progfile_reg, name='progfile_reg'),
# ]