# from datetime import timedelta, datetime
#
# today = datetime.now()
# delta = timedelta(30)
# date = today - delta
#
# print(date < today)

print(438 -(438 / 100 * 10))



sum2 = f'{sum} - ({sum} / {100} * {10})'



