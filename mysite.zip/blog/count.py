def count():
    how = 2 * 51
    return how